<?php
return array (
  'template' => 'default',
  'connectionId' => 'db',
  'tablePrefix' => 'tbl_',
  'modelPath' => 'application.models',
  'baseClass' => 'CActiveRecord',
  'buildRelations' => '1',
  'commentsAsLabels' => '0',
);
