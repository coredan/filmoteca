<?php
	/* @var $this SiteController */

	$this->pageTitle=Yii::app()->name;
	$this->breadcrumbs=array(
		'Home',
	);
?>
<div class="colpanel-title">
		Bienvenido/a!
</div>

