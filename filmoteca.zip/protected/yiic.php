<?php

// change the following paths if necessary
$yiic=dirname(__FILE__).'/../../yii-1.1.14.f0fee9/framework/yiic.php';
$config=dirname(__FILE__).'/config/console.php';

require_once($yiic);
